#!/bin/bash
# =====================================================
# 3 UAV MODEL KURULUM SCRIPTİ
# UAV_TRANSFER paketini açtıktan sonra çalıştırın
# =====================================================
echo "🚀 3 UAV Model Kurulum Başlıyor..."

# SITL_Models klasörünü kontrol et
if [ ! -d "$HOME/SITL_Models/Gazebo/models/mini_talon_vtail" ]; then
    echo "❌ HATA: ~/SITL_Models/Gazebo/models/mini_talon_vtail bulunamadı!"
    echo "   Önce SITL_Models'ı klonlayın: git clone https://github.com/ArduPilot/SITL_Models.git"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "📁 Kaynak dizin: $SCRIPT_DIR"

# --- AV1 (mini_talon_vtail) ---
echo ""
echo "📋 [1/6] AV1 kurulumu (Port 9002, mavi - ana ucak)..."
# Orijinal yedeği al
cp ~/SITL_Models/Gazebo/models/mini_talon_vtail/model.sdf \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail/model.sdf.original 2>/dev/null
# Yeni model.sdf kopyala
cp "$SCRIPT_DIR/models/mini_talon_vtail/model.sdf" \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail/model.sdf
cp "$SCRIPT_DIR/models/mini_talon_vtail/model.config" \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail/model.config
echo "   ✅ AV1 kuruldu"

# --- YEM (mini_talon_vtail_target) ---
echo ""
echo "📋 [2/6] YEM kurulumu (Port 9012, kirmizi - hedef)..."
mkdir -p ~/SITL_Models/Gazebo/models/mini_talon_vtail_target
# Mesh dosyalarını orijinal modelden kopyala
cp -r ~/SITL_Models/Gazebo/models/mini_talon_vtail/meshes \
      ~/SITL_Models/Gazebo/models/mini_talon_vtail_target/ 2>/dev/null
# Yeni model dosyalarını kopyala
cp "$SCRIPT_DIR/models/mini_talon_vtail_target/model.sdf" \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail_target/model.sdf
cp "$SCRIPT_DIR/models/mini_talon_vtail_target/model.config" \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail_target/model.config
echo "   ✅ YEM kuruldu"

# --- AV2 (mini_talon_vtail_third) ---
echo ""
echo "📋 [3/6] AV2 kurulumu (Port 9022, yesil - kamerali)..."
mkdir -p ~/SITL_Models/Gazebo/models/mini_talon_vtail_third
# Mesh dosyalarını orijinal modelden kopyala
cp -r ~/SITL_Models/Gazebo/models/mini_talon_vtail/meshes \
      ~/SITL_Models/Gazebo/models/mini_talon_vtail_third/ 2>/dev/null
# Yeni model dosyalarını kopyala
cp "$SCRIPT_DIR/models/mini_talon_vtail_third/model.sdf" \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail_third/model.sdf
cp "$SCRIPT_DIR/models/mini_talon_vtail_third/model.config" \
   ~/SITL_Models/Gazebo/models/mini_talon_vtail_third/model.config
echo "   ✅ AV2 kuruldu"

# --- QR HEDEFİ ve ZEMİN ---
# Dünya dosyası bu iki modeli de çağırıyor. Paketle gelmezlerse Gazebo
# "Unable to find uri[model://qr_target]" deyip dünyayı HİÇ açmıyor.
echo ""
echo "📋 [4/6] QR hedefi kurulumu..."
mkdir -p ~/SITL_Models/Gazebo/models/qr_target
cp -r "$SCRIPT_DIR/models/qr_target/." \
      ~/SITL_Models/Gazebo/models/qr_target/
echo "   ✅ qr_target kuruldu"

echo ""
echo "📋 [5/6] Zemin modeli..."
# Uydu görüntülü sürüm zaten varsa DOKUNMA — create_satellite_ground.py
# çalıştırılmışsa onun ürettiği model daha iyisi.
if [ -f ~/SITL_Models/Gazebo/models/satellite_ground/materials/textures/satellite.png ]; then
    echo "   ℹ️  uydu görüntülü zemin zaten kurulu, atlanıyor"
else
    mkdir -p ~/SITL_Models/Gazebo/models/satellite_ground
    cp -r "$SCRIPT_DIR/models/satellite_ground/." \
          ~/SITL_Models/Gazebo/models/satellite_ground/
    echo "   ✅ düz zemin kuruldu (uydu görüntüsü için create_satellite_ground.py)"
fi

# --- WORLD DOSYASI ---
echo ""
echo "📋 [6/6] World dosyası kurulumu..."
cp "$SCRIPT_DIR/worlds/dual_vtail_runway_3uav.sdf" \
   ~/SITL_Models/Gazebo/worlds/dual_vtail_runway_3uav.sdf
echo "   ✅ World dosyası kuruldu"

# --- DOĞRULAMA ---
echo ""
echo "========================================="
echo "📊 DOĞRULAMA"
echo "========================================="
echo ""
echo "=== AV1 ==="
ls -la ~/SITL_Models/Gazebo/models/mini_talon_vtail/model.sdf
grep "fdm_port_in" ~/SITL_Models/Gazebo/models/mini_talon_vtail/model.sdf
echo ""
echo "=== YEM ==="
ls -la ~/SITL_Models/Gazebo/models/mini_talon_vtail_target/model.sdf
grep "fdm_port_in" ~/SITL_Models/Gazebo/models/mini_talon_vtail_target/model.sdf
echo ""
echo "=== AV2 ==="
ls -la ~/SITL_Models/Gazebo/models/mini_talon_vtail_third/model.sdf
grep "fdm_port_in" ~/SITL_Models/Gazebo/models/mini_talon_vtail_third/model.sdf
grep "GstCameraPlugin" ~/SITL_Models/Gazebo/models/mini_talon_vtail_third/model.sdf
echo ""
echo "=== WORLD ==="
ls -la ~/SITL_Models/Gazebo/worlds/dual_vtail_runway_3uav.sdf
echo ""
echo "========================================="
echo "✅ KURULUM TAMAMLANDI!"
echo "========================================="
echo ""
echo "Sonraki adım: Gazebo'yu başlatın:"
echo "  export GZ_SIM_RESOURCE_PATH=\$HOME/SITL_Models/Gazebo/models:\$HOME/SITL_Models/Gazebo/worlds"
echo "  gz sim -v4 -r ~/SITL_Models/Gazebo/worlds/dual_vtail_runway_3uav.sdf"

# --- WAYPOINT DOSYALARI ---
echo ""
echo "📋 Waypoint dosyaları kurulumu..."
mkdir -p ~/SITL_Models/Gazebo/missions
cp "$SCRIPT_DIR/missions/"*.waypoints ~/SITL_Models/Gazebo/missions/ 2>/dev/null
echo "   ✅ Waypoint dosyaları kuruldu"
echo ""
echo "=== WAYPOINTS ==="
ls -la ~/SITL_Models/Gazebo/missions/*.waypoints 2>/dev/null
echo ""
echo "Waypoint yüklemek için MAVProxy'de:"
echo "  wp load ~/SITL_Models/Gazebo/missions/av_wp1.waypoints"
echo "  mode AUTO"
